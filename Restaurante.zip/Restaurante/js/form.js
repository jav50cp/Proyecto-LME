const form = document.querySelector('.form');
const usuario = document.getElementById('usuario');
const contrasena = document.getElementById('contrasena');

form.addEventListener('submit', function(event) {
  event.preventDefault();
  
  if (usuario.value.trim() === '') {
    alert('Por favor ingrese su usuario o correo electrónico.');
    usuario.focus();
    return false;
  }
  
  if (contrasena.value.trim() === '') {
    alert('Por favor ingrese su contraseña.');
    contrasena.focus();
    return false;
  }
  
  alert('¡Inicio de sesión exitoso!');
  form.reset();
});
